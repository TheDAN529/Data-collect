/** Automatically generated file. DO NOT MODIFY */
package cmu.troy.androidlogger;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}