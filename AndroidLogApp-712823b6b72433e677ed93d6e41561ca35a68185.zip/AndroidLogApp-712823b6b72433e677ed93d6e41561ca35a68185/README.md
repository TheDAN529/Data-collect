AndroidLogApp
=============
